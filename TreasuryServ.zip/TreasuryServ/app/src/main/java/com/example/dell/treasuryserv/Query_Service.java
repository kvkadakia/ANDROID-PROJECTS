package com.example.dell.treasuryserv;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import android.os.Handler;
import org.json.JSONArray;
import org.json.JSONObject;

import com.example.dell.common.ITreasuryServ;



public class Query_Service extends Service{

        private ITreasuryServ.Stub mBinder = new ITreasuryServ.Stub() {

        //This method returns a list of 12 integers as a string
        //Synchronized in order to handle multiple clients
        synchronized public List<String> monthlyCash(String s) {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                // execute code that must be run on UI thread
                @Override
                public void run() {
                    TreasuryServ.t1.setText("Service status: \nBound and running an API");
                }
            });
            List<String> list = new ArrayList<String>();
            for (int i = 0; i < 12; i++)
             {
                 findIntegers(s, list, i);
             }

            return list;
        }

         //This method accepts a date adds a value to it based on the number of working days and returns a list of Integers as a string
         synchronized public List<String> dailyCash(String d , String m, String y, String w) {
             new Handler(Looper.getMainLooper()).post(new Runnable() {
                 // execute code that must be run on UI thread
                 @Override
                 public void run() {
                     TreasuryServ.t1.setText("Service status: \nBound and running an API");
                 }
             });             String oldDate;
             if(m.length()<2 && d.length()<2)
             {
                  oldDate = y+"-0"+m+"-0"+d;
             }
             else if(m.length()<2)
             {
                  oldDate = y+"-0"+m+"-"+d;
             }
             else if(d.length()<2)
             {
                  oldDate = y+"-"+m+"-0"+d;
             }
             else {
                  oldDate = y + "-" + m + "-" + d;
             }
             //Specifying date format that matches the given date
             SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
             Calendar c = Calendar.getInstance();
             try{
                 //Setting the date to the given date
                 c.setTime(sdf.parse(oldDate));
             }catch(ParseException e){
                 e.printStackTrace();
             }
             //Number of Days to add
             c.add(Calendar.DAY_OF_MONTH, Integer.valueOf(w));
             //Date after adding the days to the given date
             String newDate = sdf.format(c.getTime());
             //Displaying the new Date after addition of Days
             List<String> list2 = new ArrayList<String>();

             String str = "" ;int sum = 0;
             try {
                 String q = "SELECT%20%22table%22%2C%20%22date%22%2C%20%22weekday%22%2C%20%22open_today%22%20FROM%20t1%20WHERE%20%28%22date%22%20%3E%20%27"+oldDate+"%27%20AND%20%22date%22%20%3C%20%27"+newDate+"%27%29";
                 URL url = new URL("http://api.treasury.io/cc7znvq/47d80ae900e04f2/sql/?q=" + q);
                 HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                 try {
                     InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                     BufferedReader r = new BufferedReader(new InputStreamReader(in));
                     StringBuilder total = new StringBuilder();
                     String line;
                     while ((line = r.readLine()) != null) {
                         total.append(line).append('\n');
                     }
                     str = total.toString();
                     JSONArray x =new JSONArray(str);
                     for(int i=0;i<x.length();i++) {
                         JSONObject jobj = x.getJSONObject(i);
                         Object object = jobj.get("open_today");
                         str = object.toString();
                         if(Integer.valueOf(str)!=0)
                         list2.add(str +"\n");
                     }

                 } finally {
                     urlConnection.disconnect();
                 }
             }
             catch(Exception e) {
                 Log.e("ERROR", e.getMessage(), e);
             }
             Set<String> hs = new HashSet<>();
             hs.addAll(list2);
             list2.clear();
             list2.addAll(hs);

             for(int i=0;i<list2.size();i++)
                 Log.i("open today",list2.get(i));

            return list2;
         }


         //This method retruns the yearly average as a string
         synchronized public String yearlyAvg(String s)
        {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                // execute code that must be run on UI thread
                @Override
                public void run() {
                    TreasuryServ.t1.setText("Service status: \nBound and running an API");
                }
            });
            String str = "" ;int sum = 0;
            try {
                String q = "SELECT%20%22table%22%2C%20%22date%22%2C%20%22weekday%22%2C%20%22open_today%22%20FROM%20t1%20WHERE%20%28%22date%22%20%3E%20%27"+s+"-01-01%27%20AND%20%22date%22%20%3C%20%27"+s+"-12-31%27%29";
                URL url = new URL("http://api.treasury.io/cc7znvq/47d80ae900e04f2/sql/?q=" + q);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                    BufferedReader r = new BufferedReader(new InputStreamReader(in));
                    StringBuilder total = new StringBuilder();
                    String line;int count=0;
                    while ((line = r.readLine()) != null) {
                        total.append(line).append('\n');
                    }
                    str = total.toString();
                    JSONArray x =new JSONArray(str);
                    for(int i=0;i<x.length();i++) {
                        JSONObject jobj = x.getJSONObject(i);
                        Object object = jobj.get("open_today");
                        str = object.toString();
                        sum =sum + Integer.valueOf(str);
                    }

                    sum = sum /x.length();
                } finally {
                    urlConnection.disconnect();
                }
            }
            catch(Exception e) {
                Log.e("ERROR", e.getMessage(), e);
            }


            return "\n\n\nYearly Average for year "+s+"= "+String.valueOf(sum);
        }

    };

    //This method finds the integers for montly cash api
    public void findIntegers(String s, List<String> list, Integer i)
    {
        String str= "";
        try {
            String q;
            if(i<9) {
                 q = "SELECT%20%22table%22%2C%20%22date%22%2C%20%22weekday%22%2C%20%22open_today%22%0D%0AFROM%0D%0At1%0D%0AWHERE%20%28%22date%22%20%3E%20%27" + s + "-" + "0" + String.valueOf(i + 1) + "-01%27%20AND%20%22date%22%20%3C%20%27" + s + "-" + "0" + String.valueOf(i + 1) + "-08%27%29";
            }
            else
            {
                 q = "SELECT%20%22table%22%2C%20%22date%22%2C%20%22weekday%22%2C%20%22open_today%22%0D%0AFROM%0D%0At1%0D%0AWHERE%20%28%22date%22%20%3E%20%27" + s + "-" + String.valueOf(i + 1) + "-01%27%20AND%20%22date%22%20%3C%20%27" + s + "-" + String.valueOf(i + 1) + "-08%27%29";
            }

            URL url = new URL("http://api.treasury.io/cc7znvq/47d80ae900e04f2/sql/?q="+q);

        HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
        try {
            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            StringBuilder total = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) {
                total.append(line).append('\n');
            }
            str = total.toString();
            JSONArray x =new JSONArray(str);
            JSONObject jobj= x.getJSONObject(0);
            Object object = jobj.get("open_today");
            str = object.toString();
            list.add(str + "\n");
        } finally {
            urlConnection.disconnect();
        }
     }
     catch(Exception e) {
        Log.e("ERROR", e.getMessage(), e);
     }
    }


    @Override
    public IBinder onBind(Intent intent) {
        Log.i("Ibinder", "Bound to one or more clients but idle");
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            // execute code that must be run on UI thread
            @Override
            public void run() {
                TreasuryServ.t1.setText("Service status: \nBound to one or more clients but idle");
            }
        });
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.i("Ibinder", "unbind");
        return true;
    }

    @Override
    public void onDestroy() {
        Log.i("Destroyed", "in onDestroy");
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            // execute code that must be run on UI thread
            @Override
            public void run() {
                TreasuryServ.t1.setText("Service status: \nDestroyed");
            }
        });
    }
}


