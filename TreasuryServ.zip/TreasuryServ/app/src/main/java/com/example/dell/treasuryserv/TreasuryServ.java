package com.example.dell.treasuryserv;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;


public class TreasuryServ extends AppCompatActivity {
    public static TextView t1;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_treasury_serv);
         t1 = (TextView)findViewById(R.id.t1);
    }


}



